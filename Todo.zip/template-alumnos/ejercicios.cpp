#include "ejercicios.h"
#include "auxiliares.h"
#include <iostream>
#include <algorithm>
#include <fstream>
#include <iomanip>

using namespace std;

/******++++**************************** EJERCICIO tiempoTotal ***********+++***********************/
tiempo tiempoTotal(viaje v) {
    tiempo t=0;
    tiempo tmin=minTiempoViaje(v);
    tiempo tmax=maxTiempoViaje(v);
    t=tmax-tmin;
    return t;
}

/************++*********************** EJERCICIO distanciaTotal ************++*********************/
distancia distanciaTotal(viaje v) {
    distancia d=0;
    v=ordenarPorTiempo(v);
    d=distanciaViaje(v);
    return d;
}

/*****************************+***** EJERCICIO excesoDeVelocidad **********************************/
bool excesoDeVelocidad(viaje v) {
    bool resp = false;
    v=ordenarPorTiempo(v);
    for(int i=0; i< v.size()-1; i=i+1){
        if(vel(v[i], v[i+1])>80){
            resp=true;
        }
    }
    return resp;
}

/************************************ EJERCICIO recorridoCubierto *******************************/
vector<gps> recorridoNoCubierto(viaje v, recorrido r, distancia u) {
    vector<gps> resp;
    bool foundCoverer;
    double distanciaEntreAmbos;
    for (int i=0; i<r.size();i++) {
        foundCoverer = false;
        for (int j = 0; j < v.size(); j++) {
            distanciaEntreAmbos = distEnKM( r[i],obtenerPosicion(v[j]));
            if (distanciaEntreAmbos < u) {
                foundCoverer = true;
                break;
            }
        }
        if (not foundCoverer)
            resp.push_back(r[i]);
    }

    return resp;
}

/***************************************** EJERCICIO flota ***************************************/
int flota(vector<viaje> f, tiempo t0, tiempo tf) {
    int resp = 0;
    tiempo tiempoMin = 0;
    tiempo tiempoMax = 0;
    for(int i = 0; i < f.size(); ++i) {
        tiempoMin = minTiempoViaje(f[i]);
        tiempoMax = maxTiempoViaje(f[i]);
        if(not(tiempoMax <= t0 || tf <= tiempoMin)) {
            ++resp;
        }
    }

    return resp;
}

/************************************** EJERCICIO construirGrilla *******************************/
grilla construirGrilla(gps esq1, gps esq2, int n, int m) {
    grilla resp = {};
    int cantColumnas = m;
    int cantFilas = n;
    double anchoCelda = (obtenerLongitud(esq2) - obtenerLongitud(esq1)) / cantColumnas;
    double altoCelda = (obtenerLatitud(esq1) - obtenerLatitud(esq2)) / cantFilas;
    gps esqSupIzq = esq1;
    gps esqInfDer = puntoGps(obtenerLatitud(esq1) - altoCelda, obtenerLongitud(esq1) + anchoCelda);
    for(int i = 0; i < cantFilas; ++i) {
        for(int j = 0; j < cantColumnas; ++j) {
            gps nuevaEsqSupIzq = puntoGps(obtenerLatitud(esqSupIzq) - (i * altoCelda), obtenerLongitud(esqSupIzq) + (j * anchoCelda));
            gps nuevaEsqInfDer = puntoGps(obtenerLatitud(esqInfDer) - (i * altoCelda), obtenerLongitud(esqInfDer) + (j * anchoCelda));
            nombre nuevoNombre = make_tuple(i+1,j+1);
            resp.push_back(make_tuple(nuevaEsqSupIzq, nuevaEsqInfDer, nuevoNombre));
        }
    }

    return resp;
}

/************************************* EJERCICIO cantidadDeSaltos ******************************/
int cantidadDeSaltos(grilla g, viaje v) {
    int resp = 0;
    viaje viajeOrdenado = ordenarPorTiempo(v);
    for(int i = 0; i < v.size()-1; ++i) {
        celda celdaDeGps1 = celdaDelGps(g,obtenerPosicion(viajeOrdenado[i]));
        celda celdaDeGps2 = celdaDelGps(g,obtenerPosicion(viajeOrdenado[i+1]));
        if(distanciaEntreCeldas(celdaDeGps1,celdaDeGps2) > 1) {
            ++resp;
        }
    }

    return resp;
}


/************************************* EJERCICIO corregirViaje ******************************/
void corregirViaje(viaje& v, vector<tiempo> errores){
    viaje viajeOrdenado = ordenarPorTiempo(v);
    viaje puntosMasCercanos;
    tiempo tiempoDeError;
    int indiceDeErrorEnViaje;
    for(int i = 0; i < errores.size(); ++i){
        tiempoDeError = errores[i];
        indiceDeErrorEnViaje = busquedaBinariaEnViajes(viajeOrdenado, tiempoDeError);
        puntosMasCercanos = buscarPuntosMasCercanos(viajeOrdenado, errores, indiceDeErrorEnViaje);
        v[indiceDeErrorEnViaje] = corregirPunto(puntosMasCercanos, tiempoDeError);
    }
}