#include <algorithm>
#include "auxiliares.h"
#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

const double pi = 3.14;
double radioTierra = 6378;

tiempo minTiempoViaje(viaje v){
    tiempo minimo = obtenerTiempo(v[0]);
    for(int i=0; i<v.size(); i=i+1){
        if(minimo > obtenerTiempo(v[i])){
            minimo = obtenerTiempo(v[i]);
        }
    }
    return minimo;
}

tiempo maxTiempoViaje(viaje v){
    tiempo maximo = obtenerTiempo(v[0]);
    for(int i=0; i<v.size(); i=i+1){
        if(maximo < obtenerTiempo(v[i])){
            maximo = get<0>(v[i]);
        }
    }
    return maximo;
}

viaje ordenarPorTiempo(viaje v) {
    tuple<tiempo,gps> elMayor;
    for(int i = 0; i < v.size()-1; ++i) {
        for(int j = 0; j < v.size()-1; ++j) {
            if(get<0>(v[j+1]) <= get<0>(v[j])){
                elMayor = v[j];
                v[j] = v[j+1];
                v[j+1] = elMayor;
            }
        }
    }
    return v;
}

distancia distanciaViaje(viaje v){
    distancia suma=0;
    for(int i=0; i<v.size()-1; i=i+1){
        distancia distanciaRelativa = distEnKM(obtenerPosicion(v[i]), obtenerPosicion(v[i+1]));
        suma = suma + distanciaRelativa;
    }
    return suma;
}

velocidad vel(elementoDeViaje e1, elementoDeViaje e2){
    distancia dist = distEnKM(obtenerPosicion(e2), obtenerPosicion(e1));
    tiempo t = obtenerTiempo(e2) - obtenerTiempo(e1);
    return (dist/t)*(3600);
}

celda celdaDelGps(grilla g, gps p) {
    int i = 0;
    double latMin = 0;
    double latMax = 0;
    double longMin = 0;
    double longMax = 0;
    double pLat = obtenerLatitud(p);
    double pLong = obtenerLongitud(p);
    bool seEncontroLaCelda = false;
    while(not(seEncontroLaCelda)) {
        latMin = obtenerLatitud(get<1>(g[i]));
        latMax = obtenerLatitud(get<0>(g[i]));
        longMin = obtenerLongitud(get<0>(g[i]));
        longMax = obtenerLongitud(get<1>(g[i]));
        seEncontroLaCelda = ((latMin <= pLat < latMax) && (longMin <= pLong < longMax));
        ++i;
    }
    --i;
    return g[i];
}

double distanciaEntreCeldas(celda celda1, celda celda2) {
    nombre nombre1 = get<2>(celda1);
    nombre nombre2 = get<2>(celda2);
    double distancia = sqrt(pow(get<0>(nombre1) - get<0>(nombre2),2) + pow(get<1>(nombre1) - get<1>(nombre2),2));
    return distancia;
}

int busquedaBinariaEnViajes(viaje v, tiempo t) {
    int lowIndice = 0;
    int highIndice = v.size() - 1;
    int resultado = -1;
    bool buscando = true;
    while(buscando){
        int midIndice = (highIndice - lowIndice) / 2;
        if(obtenerTiempo(v[lowIndice + midIndice]) < t && midIndice != 0) {
            lowIndice = lowIndice + midIndice;
        } else if(obtenerTiempo(v[lowIndice + midIndice]) > t && midIndice != 0){
            highIndice = lowIndice + midIndice;
        } else{
            if(obtenerTiempo(v[0]) == t){
                resultado = 0; buscando = false;
            } else if(obtenerTiempo(v[v.size() - 1]) == t){
                resultado = v.size() - 1; buscando = false;
            } else{
                resultado = (lowIndice+midIndice);
                buscando = false;
            }
        }
    }
    return resultado;
}

bool busquedaBinaria(vector<tiempo> tiempos, double n) {
    int lowIndice = 0;
    int highIndice = tiempos.size() - 1;
    bool resultado = false;
    bool buscando = true;
    while(buscando){
        int midIndice = (highIndice - lowIndice) / 2;

        if(tiempos[lowIndice + midIndice] < n && midIndice != 0) {
            lowIndice = lowIndice + midIndice;
        }
        else if(tiempos[lowIndice + midIndice] > n && midIndice != 0){
            highIndice = lowIndice + midIndice;
        }

        else{
            if(tiempos[0] == n){
                resultado = true;
                buscando = false;
            }
            else if(tiempos[tiempos.size() - 1] == n){
                resultado = true;
                buscando = false;
            }
            else{
                resultado = tiempos[lowIndice+midIndice] == n;
                buscando = false;
            }
        }
    }
    return resultado;
}


int buscarIndiceInicial(viaje v, vector<tiempo> errores, int indiceDeError, int ignorarIndice){
    int i = 0;
    int resultado;
    bool buscando = true;
    bool estaEnErrores;
    double distancia;
    while(buscando){
        estaEnErrores = busquedaBinaria(errores, obtenerTiempo(v[i]));
        distancia = abs(obtenerTiempo(v[i]) - obtenerTiempo(v[indiceDeError]));
        if(distancia != 0 && i != ignorarIndice && not(estaEnErrores)){
            resultado = i;
            buscando = false;
        }
        ++i;
    }
    return resultado;
}

int buscarIndiceDelMasCercano(viaje v, vector<tiempo> errores, int indiceDeError, int ignorarIndice) {
    int indiceInicial = buscarIndiceInicial(v, errores, indiceDeError, ignorarIndice);
    int indiceDePuntoMasCercano = indiceInicial;
    bool estaEnErrores;
    double distanciaMinima;
    double distanciaSiguiente;
    for(int i = indiceInicial; i < v.size(); ++i){
        estaEnErrores = busquedaBinaria(errores, obtenerTiempo(v[i]));
        distanciaMinima = abs(obtenerTiempo(v[indiceDePuntoMasCercano]) - obtenerTiempo(v[indiceDeError]));
        distanciaSiguiente = abs(obtenerTiempo(v[i]) - obtenerTiempo(v[indiceDeError]));
        if(i != indiceDeError && i != ignorarIndice && distanciaSiguiente < distanciaMinima && not(estaEnErrores)) {
            indiceDePuntoMasCercano = i;
        }
    }
    return indiceDePuntoMasCercano;
}

viaje buscarPuntosMasCercanos(viaje v, vector<tiempo> errores, int indiceDeError) {
    viaje puntosMasCercanos;
    int indiceDePuntoMasCercano1 = buscarIndiceDelMasCercano(v, errores, indiceDeError,-1);
    int indiceDePuntoMasCercano2 = buscarIndiceDelMasCercano(v, errores, indiceDeError,indiceDePuntoMasCercano1);
    puntosMasCercanos.push_back(v[indiceDePuntoMasCercano1]);
    puntosMasCercanos.push_back(v[indiceDePuntoMasCercano2]);
    return puntosMasCercanos;
}

tuple<tiempo, gps> corregirPunto(viaje puntosMasCercanos, tiempo tiempoDeError){
    tiempo pTiempo = obtenerTiempo(puntosMasCercanos[0]);
    tiempo qTiempo = obtenerTiempo(puntosMasCercanos[1]);
    double pLat = obtenerLatitud(obtenerPosicion(puntosMasCercanos[0]));
    double pLong = obtenerLongitud(obtenerPosicion(puntosMasCercanos[0]));
    double qLat = obtenerLatitud(obtenerPosicion(puntosMasCercanos[1]));
    double qLong = obtenerLongitud(obtenerPosicion(puntosMasCercanos[1]));
    tiempo tiempoDesdePuntoMasCercano = tiempoDeError - pTiempo;
    gps direccionDeCorreccion = puntoGps((qLat - pLat) / (qTiempo - pTiempo), (qLong - pLong) / (qTiempo - pTiempo));
    gps correccion = puntoGps(pLat + (tiempoDesdePuntoMasCercano * obtenerLatitud(direccionDeCorreccion)), pLong + (tiempoDesdePuntoMasCercano * obtenerLongitud(direccionDeCorreccion)));
    return medicion(tiempoDeError,correccion);
}

double obtenerLatitud(gps posicion) {
    return get<0>(posicion);
}

double obtenerLongitud(gps posicion) {
    return get<1>(posicion);
}

gps obtenerPosicion(tuple<tiempo, gps> medicion) {
    return get<1>(medicion);
}

tiempo obtenerTiempo(tuple<tiempo, gps> medicion) {
    return get<0>(medicion);
}
double distEnKM(gps posicion1, gps posicion2) {
    double latitud1 = obtenerLatitud(posicion1);
    double latitud2 = obtenerLatitud(posicion2);
    double longitud1 = obtenerLongitud(posicion1);
    double longitud2 = obtenerLongitud(posicion2);

    // obtengo la distancia
    double distanciaLatitud = (latitud2 - latitud1) * pi / 180.0;
    double distanciaLongitud = (longitud2 - longitud1) * pi / 180.0;

    // paso las latitudes a radianes
    latitud1 = (latitud1) * pi / 180.0;
    latitud2 = (latitud2) * pi / 180.0;

    // aplico la formula
    double a = pow(sin(distanciaLatitud / 2), 2) +
               pow(sin(distanciaLongitud / 2), 2) *
               cos(latitud1) * cos(latitud2);

    double c = 2 * asin(sqrt(a));
    return radioTierra * c;
}

gps desviarPunto(gps p, double desvioMtsLatitud, double desvioMtsLongitud){
    double lat = obtenerLatitud(p);
    double lon = obtenerLongitud(p);

    double dx = desvioMtsLatitud / 1000;
    double dy = desvioMtsLongitud / 1000;
    double new_latitude = lat + (dx / radioTierra) * (180 / pi);
    double new_longitude = lon + (dy / radioTierra) * (180 / pi) / cos(lat * pi / 180);
    return puntoGps(new_latitude, new_longitude);

}


gps puntoGps(double latitud, double longitud) {
    return make_tuple(latitud, longitud);
}

tuple<tiempo, gps> medicion(tiempo t, gps g) {
    return make_tuple(t, g);
}

/*void guardarGrillaEnArchivo(grilla g, string nombreArchivo){
    ofstream myfile;
    float esq1_lat, esq2_lat, esq1_lng, esq2_lng;
    int name_0, name_1;

    myfile.open(nombreArchivo);
    myfile << std::fixed << std::setprecision(5);
    for(int i = 0; i < g.size(); i++){
        esq1_lat = get<0>(get<0>(g[i]));
        esq1_lng = get<1>(get<0>(g[i]));

        esq2_lat = get<0>(get<1>(g[i]));
        esq2_lng = get<1>(get<1>(g[i]));

        name_0 = get<0>(get<2>(g[i]));
        name_1 = get<1>(get<2>(g[i]));

        myfile << esq1_lat << "\t"
               << esq1_lng << "\t"
               << esq2_lat << "\t"
               << esq2_lng << "\t"
               << "(" << name_0 << "," << name_1 << ")"
               << endl;

    }
    myfile.close();

}

void guardarRecorridosEnArchivo(vector<recorrido> recorridos, string nombreArchivo){
    ofstream myfile;
    float lat, lng;

    myfile.open(nombreArchivo);
    myfile << std::fixed << std::setprecision(5);
    for(int i = 0; i < recorridos.size(); i++){
        for(int k = 0; k < recorridos[i].size(); k++){
            lat= get<0>(recorridos[i][k]);
            lng= get<1>(recorridos[i][k]);

            myfile << i << "\t"
                   << lat << "\t"
                   << lng << endl;
        }
    }
    myfile.close();

}
*/